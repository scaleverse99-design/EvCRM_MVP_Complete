(function(){"use strict";function b(){const i=document.querySelectorAll('.font-claude-message, [data-testid="user-message"], [data-testid="assistant-message"], .chat-message, .message-bubble');if(i.length===0){const e=document.querySelectorAll("div.chat-container p, .message p, div.flex-col.items-start p, article p");return e.length>0?Array.from(e).map(t=>t.textContent||"").filter(t=>t.trim().length>0).join(`
`):document.body.innerText||""}const o=[];return i.forEach(e=>{const t=(e.textContent||"").trim();if(!t)return;let n="Assistant";(e.getAttribute("data-testid")==="user-message"||e.classList.contains("user")||e.closest(".user")||e.parentElement&&e.parentElement.classList.contains("user")||(e.textContent||"").toLowerCase().startsWith("user:"))&&(n="User");const p=t.replace(/^(user|ai|assistant|claude)[:\-\s]+/i,"").trim();o.push(`${n}: ${p}`)}),o.join(`

`)}function v(){const i=document.querySelectorAll('[data-testid^="conversation-turn-"], [data-testid^="conversation-turn"], div.group.w-full, article');if(i.length===0){const e=document.querySelectorAll("main p, div.markdown.prose p, .message p");return e.length>0?Array.from(e).map(t=>t.textContent||"").filter(t=>t.trim().length>0).join(`
`):document.body.innerText||""}const o=[];return i.forEach(e=>{const t=(e.textContent||"").trim();if(!t)return;let n="Assistant";(e.querySelector('[data-testid^="user-"], .user-avatar, img[alt^="User"]')||e.querySelector("div.flex-col.gap-1.md\\:gap-3.items-end")||(e.textContent||"").toLowerCase().startsWith("user:"))&&(n="User");const p=t.replace(/^(user|ai|assistant|chatgpt)[:\-\s]+/i,"").trim();o.push(`${n}: ${p}`)}),o.join(`

`)}function y(i,o){const e=i.split(`
`).map(s=>s.trim()).filter(s=>s.length>0);let t="General Discussion";for(const s of e){if(s.startsWith("```")||s.length<5)continue;const a=s.replace(/^(user|ai|model|claude|chatgpt|assistant|prompt|system|q|a|human|bot|developer|helper)[:\-\s]+/i,"").trim();if(a.length>5){t=a.substring(0,100),a.length>100&&(t+="...");break}}const n=[];for(const s of e){if(s.startsWith("```")||s.length<15)continue;const a=s.replace(/^(user|ai|model|claude|chatgpt|assistant|prompt|system|q|a|human|bot|developer|helper)[:\-\s]+/i,"").trim(),d=a.toLowerCase();if((a.startsWith("-")||a.startsWith("*")||/^\d+\./.test(a)||d.includes("create")||d.includes("implement")||d.includes("fixed")||d.includes("resolve")||d.includes("use")||d.includes("add")||d.includes("configure")||d.includes("deploy"))&&!a.includes("```")){const c=a.replace(/^[-*\d\.\s]+/,"").trim();if(c.length>10&&c.length<400&&!n.includes(c)&&(n.push(c),n.length>=10))break}}if(n.length<3)for(const s of e){if(s.startsWith("```")||s.length<15)continue;const a=s.replace(/^(user|ai|model|claude|chatgpt|assistant|prompt|system|q|a|human|bot|developer|helper)[:\-\s]+/i,"").trim();if(a.length>15&&a.length<400&&!n.includes(a)&&(n.push(a),n.length>=8))break}const r=new Set,p=new Set,u=/(?:[a-zA-Z]:\\)?[a-zA-Z0-9_\-\.\/]+\/[a-zA-Z0-9_\-\.\/]+\.[a-zA-Z0-9]+/g,g=/\b[a-zA-Z0-9_\-]+\.(?:ts|tsx|js|jsx|py|go|java|cpp|h|css|html|json|md|yaml|yml)\b/gi,w=/\b[a-zA-Z0-9_]+(?:[A-Z][a-zA-Z0-9_]+|[a-z0-9]+_[a-zA-Z0-9_]+)\b/g;let l;for(;(l=u.exec(i))!==null;)!l[0].includes("http")&&l[0].length<120&&r.add(l[0].replace(/\\/g,"/"));for(;(l=g.exec(i))!==null;)l[0].length<80&&r.add(l[0]);for(;(l=w.exec(i))!==null;)isNaN(Number(l[0]))&&l[0].length>4&&l[0].length<50&&p.add(l[0]);let x="Continue implementation and validation of the codebase.";const E=[/todo:\s*(.+)/i,/fixme:\s*(.+)/i,/-\s*\[\s*\]\s*(.+)/i,/\b(?:need\s+to|should\s+implement|must\s+fix|will\s+add)\s+(.+)/i];for(const s of e){let a=!1;for(const d of E){const f=s.match(d);if(f&&f[1]){let c=f[1].trim();if(c=c.replace(/[;,\s]+$/,""),c.length>5){c.length>250&&(c=c.substring(0,247)+"..."),x=c,a=!0;break}}}if(a)break}const L=new Date().toISOString();let m=`[CAPSULE CONTEXT HANDOFF]
=========================================
SOURCE TOOL : ${o.toUpperCase()}
TIMESTAMP   : ${L}
TOPIC       : ${t}

--- DISCUSSION SUMMARY ---
`;return n.length>0?m+=n.map(s=>`* ${s}`).join(`
`)+`
`:m+=`* Context discussion details captured from session logs.
`,(r.size>0||p.size>0)&&(m+=`
--- CODE & FILE REFERENCES ---
`,r.size>0&&(m+=`* **File Paths:** ${Array.from(r).map(s=>`\`${s}\``).join(", ")}
`),p.size>0&&(m+=`* **Identifiers:** ${Array.from(p).slice(0,15).map(s=>`\`${s}\``).join(", ")}
`)),m+=`
--- SUGGESTED NEXT STEP ---
* ${x}

=========================================
`,m}function C(i){if(document.getElementById("capsule-overlay-root"))return;const o=document.createElement("div");o.id="capsule-overlay-root",document.body.appendChild(o);const e=document.createElement("style");e.textContent=`
    #capsule-overlay-root {
      position: fixed;
      bottom: 24px;
      right: 88px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .capsule-trigger {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #6366f1, #4f46e5);
      box-shadow: 0 4px 12px rgba(79, 70, 229, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      border: 1px solid rgba(255, 255, 255, 0.15);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .capsule-trigger:hover {
      transform: scale(1.08) translateY(-2px);
      box-shadow: 0 6px 16px rgba(79, 70, 229, 0.5);
    }
    .capsule-trigger svg {
      width: 22px;
      height: 22px;
      fill: #ffffff;
      transition: transform 0.4s ease;
    }
    .capsule-trigger.open svg {
      transform: rotate(135deg);
    }
    .capsule-panel {
      position: absolute;
      bottom: 60px;
      right: 0;
      width: 260px;
      background: rgba(15, 23, 42, 0.95);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(8px);
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 12px;
      opacity: 0;
      transform: translateY(10px) scale(0.95);
      pointer-events: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .capsule-panel.visible {
      opacity: 1;
      transform: translateY(0) scale(1);
      pointer-events: auto;
    }
    .capsule-title {
      font-size: 13px;
      font-weight: 700;
      color: #f8fafc;
      margin: 0;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .capsule-desc {
      font-size: 11px;
      color: #94a3b8;
      margin: 0;
      line-height: 1.4;
    }
    .capsule-btn {
      width: 100%;
      background: #4f46e5;
      color: #ffffff;
      border: none;
      padding: 10px 14px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: background 0.2s ease;
    }
    .capsule-btn:hover {
      background: #4338ca;
    }
    .capsule-btn:disabled {
      background: #334155;
      color: #64748b;
      cursor: not-allowed;
    }
    .capsule-toast {
      position: fixed;
      bottom: 90px;
      right: 24px;
      background: #10b981;
      color: #ffffff;
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
      opacity: 0;
      transform: translateY(10px);
      pointer-events: none;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .capsule-toast.show {
      opacity: 1;
      transform: translateY(0);
    }
  `,document.head.appendChild(e),o.innerHTML=`
    <div class="capsule-panel" id="capsule-panel">
      <h4 class="capsule-title">Capsule Context Hub</h4>
      <p class="capsule-desc">Extracts and summarizes this conversation thread to carry it to another AI tool.</p>
      <button class="capsule-btn" id="capsule-copy-btn">
        <svg style="width:14px; height:14px; fill:currentColor" viewBox="0 0 24 24">
          <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
        </svg>
        Copy Context Capsule
      </button>
    </div>
    <div class="capsule-trigger" id="capsule-trigger">
      <svg viewBox="0 0 24 24" id="capsule-trigger-icon">
        <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
      </svg>
    </div>
    <div class="capsule-toast" id="capsule-toast">
      <span>✅ Context capsule copied to clipboard!</span>
    </div>
  `;const t=document.getElementById("capsule-trigger"),n=document.getElementById("capsule-panel"),r=document.getElementById("capsule-copy-btn"),p=document.getElementById("capsule-toast");t.addEventListener("click",()=>{const u=n.classList.toggle("visible");t.classList.toggle("open",u)}),document.addEventListener("click",u=>{o.contains(u.target)||(n.classList.remove("visible"),t.classList.remove("open"))}),r.addEventListener("click",async()=>{const u=r.innerHTML;r.setAttribute("disabled","true"),r.textContent="Extracting...";try{const g=await i();await navigator.clipboard.writeText(g),p.classList.add("show"),setTimeout(()=>{p.classList.remove("show")},2500),n.classList.remove("visible"),t.classList.remove("open")}catch(g){console.error("[Capsule] Extraction failed:",g),alert(`Capsule extraction failed: ${g.message||g}`)}finally{r.removeAttribute("disabled"),r.innerHTML=u}})}function h(){const i=window.location.hostname;let o="manual",e=()=>"";if(i.includes("claude.ai"))o="claude",e=b,console.log("[Capsule] Claude AI adapter active.");else if(i.includes("chatgpt.com")||i.includes("openai.com"))o="chatgpt",e=v,console.log("[Capsule] ChatGPT adapter active.");else{console.warn("[Capsule] Unsupported hostname:",i);return}C(async()=>{const t=e();if(!t.trim())throw new Error("No readable conversation text found on this page.");return y(t,o)})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",h):h()})();
